// Newtonite Operations Coordinator Frontend Application
let currentUser = null;
let allUsers = [];
let allTeams = [];
let currentTab = 'dashboard';
let currentItemDetail = null;

// Pagination state
let currentOffset = 0;
const currentLimit = 15;
let currentFilters = {
  status: '',
  priority: '',
  category: '',
  assigned_team: '',
  assignee_id: '',
  sla_risk_level: '',
  unassigned_only: false,
  search: ''
};

// DOM Init
document.addEventListener('DOMContentLoaded', async () => {
  await loadUsersAndTeams();
  setupEventListeners();
  switchTab('dashboard');
});

// Toast notification helper
function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `<span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// User & Persona Switcher
async function loadUsersAndTeams() {
  try {
    const [uRes, tRes] = await Promise.all([
      fetch('/api/users'),
      fetch('/api/teams')
    ]);
    allUsers = await uRes.json();
    allTeams = await tRes.json();

    const personaSelect = document.getElementById('personaSelect');
    personaSelect.innerHTML = '';
    allUsers.forEach(u => {
      const opt = document.createElement('option');
      opt.value = u.id;
      opt.textContent = `${u.name} (${u.title})`;
      personaSelect.appendChild(opt);
    });

    const savedUserId = localStorage.getItem('newtonite_user_id') || 'usr_alice';
    personaSelect.value = savedUserId;
    await setCurrentUser(savedUserId);
  } catch (err) {
    console.error('Failed to load users/teams:', err);
    showToast('Failed to initialize users and teams', 'error');
  }
}

async function setCurrentUser(userId) {
  currentUser = allUsers.find(u => u.id === userId) || allUsers[0];
  localStorage.setItem('newtonite_user_id', currentUser.id);

  // Update header UI
  document.getElementById('userAvatarInitial').textContent = currentUser.name.charAt(0);
  const teamsContainer = document.getElementById('userTeamsBadges');
  teamsContainer.innerHTML = '';
  currentUser.teams.forEach(t => {
    const pill = document.createElement('span');
    pill.className = 'team-pill';
    pill.textContent = t.replace('_', ' ');
    teamsContainer.appendChild(pill);
  });

  // Refresh active view
  if (currentTab === 'dashboard') {
    loadDashboard();
  } else if (currentTab === 'items') {
    loadWorkItems();
  }
}

// Tab Switching
function switchTab(tabId) {
  currentTab = tabId;
  document.querySelectorAll('.nav-tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === tabId);
  });

  document.getElementById('tabDashboard').style.display = tabId === 'dashboard' ? 'block' : 'none';
  document.getElementById('tabItems').style.display = tabId === 'items' ? 'block' : 'none';
  document.getElementById('tabSimulator').style.display = tabId === 'simulator' ? 'block' : 'none';
  document.getElementById('tabAsyncJobs').style.display = tabId === 'async' ? 'block' : 'none';

  if (tabId === 'dashboard') loadDashboard();
  if (tabId === 'items') loadWorkItems();
  if (tabId === 'async') loadAsyncJobs();
}

// Helper: Custom fetch with user header
async function apiFetch(url, options = {}) {
  options.headers = options.headers || {};
  if (currentUser) {
    options.headers['X-User-Id'] = currentUser.id;
  }
  return fetch(url, options);
}

// ----------------- DASHBOARD VIEW -----------------

async function loadDashboard() {
  try {
    const res = await apiFetch('/api/dashboard');
    if (!res.ok) throw new Error('Dashboard fetch failed');
    const data = await res.json();

    // KPIs
    document.getElementById('kpiActiveCount').textContent = data.kpis.total_active;
    document.getElementById('kpiTriageCount').textContent = data.kpis.triage_count;
    document.getElementById('kpiPendingApprovals').textContent = data.kpis.pending_approvals_count;
    document.getElementById('kpiSlaBreaches').textContent = data.kpis.sla_breach_count;
    document.getElementById('kpiMyItems').textContent = data.kpis.my_assigned_count;

    // Queues
    renderQueueList('queueTriageList', data.queues.triage, 'No unassigned items in triage queue.');
    renderQueueList('queueApprovalsList', data.queues.approvals, 'No items currently pending approval.');
    renderQueueList('queueSlaList', data.queues.sla_risks, 'No items currently at SLA risk.');
    renderQueueList('queueMyItemsList', data.queues.my_items, 'You have no assigned active items.');
  } catch (err) {
    console.error(err);
    showToast('Error loading dashboard overview', 'error');
  }
}

function renderQueueList(containerId, items, emptyMessage) {
  const container = document.getElementById(containerId);
  container.innerHTML = '';
  if (!items || items.length === 0) {
    container.innerHTML = `<div style="color: var(--text-muted); font-size: 0.8rem; padding: 0.5rem 0;">${emptyMessage}</div>`;
    return;
  }

  items.forEach(item => {
    const row = document.createElement('div');
    row.className = 'queue-item-row';
    row.onclick = () => openItemDetail(item.id);

    const prioBadge = `<span class="badge-priority priority-${item.priority.toLowerCase()}">${item.priority}</span>`;
    const statusBadge = `<span class="badge-status status-${item.status.toLowerCase()}">${item.status.replace('_', ' ')}</span>`;
    
    let slaBadge = '';
    if (item.sla_risk_level === 'BREACHED') {
      slaBadge = `<span class="badge-sla sla-breached">SLA BREACHED</span>`;
    } else if (item.sla_risk_level === 'WARN') {
      slaBadge = `<span class="badge-sla sla-warn">SLA WARN</span>`;
    }

    row.innerHTML = `
      <div class="queue-item-top">
        <div style="display:flex; align-items:center; gap:0.4rem; overflow:hidden;">
          ${prioBadge}
          <span class="queue-item-title">${escapeHtml(item.title)}</span>
        </div>
        ${slaBadge}
      </div>
      <div class="queue-item-meta">
        ${statusBadge}
        <span>Team: ${item.assigned_team_name || item.assigned_team}</span>
        <span>•</span>
        <span>${item.assignee_name ? 'Assigned: ' + item.assignee_name : '<span style="color:#38bdf8;">UNASSIGNED</span>'}</span>
      </div>
    `;
    container.appendChild(row);
  });
}

// ----------------- WORK ITEMS TABLE VIEW -----------------

async function loadWorkItems() {
  try {
    const params = new URLSearchParams();
    params.set('limit', currentLimit);
    params.set('offset', currentOffset);

    if (currentFilters.status) params.set('status', currentFilters.status);
    if (currentFilters.priority) params.set('priority', currentFilters.priority);
    if (currentFilters.category) params.set('category', currentFilters.category);
    if (currentFilters.assigned_team) params.set('assigned_team', currentFilters.assigned_team);
    if (currentFilters.sla_risk_level) params.set('sla_risk_level', currentFilters.sla_risk_level);
    if (currentFilters.unassigned_only) params.set('unassigned_only', 'true');
    if (currentFilters.search) params.set('search', currentFilters.search);

    const res = await apiFetch(`/api/work-items?${params.toString()}`);
    if (!res.ok) throw new Error('Failed to fetch items');
    const data = await res.json();

    const tbody = document.getElementById('workItemsTableBody');
    tbody.innerHTML = '';

    if (data.items.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 2rem;">No operational work items match the selected criteria.</td></tr>`;
    } else {
      data.items.forEach(item => {
        const tr = document.createElement('tr');
        tr.onclick = () => openItemDetail(item.id);

        const prioBadge = `<span class="badge-priority priority-${item.priority.toLowerCase()}">${item.priority}</span>`;
        const statusBadge = `<span class="badge-status status-${item.status.toLowerCase()}">${item.status.replace('_', ' ')}</span>`;
        
        let slaBadge = `<span class="badge-sla sla-normal">Normal</span>`;
        if (item.sla_risk_level === 'BREACHED') {
          slaBadge = `<span class="badge-sla sla-breached">BREACHED</span>`;
        } else if (item.sla_risk_level === 'WARN') {
          slaBadge = `<span class="badge-sla sla-warn">AT RISK</span>`;
        }

        tr.innerHTML = `
          <td>${prioBadge}</td>
          <td class="item-title-cell">${escapeHtml(item.title)}</td>
          <td><span style="font-size:0.75rem; text-transform:capitalize;">${item.category.replace('_', ' ')}</span></td>
          <td>${statusBadge}</td>
          <td>${item.assigned_team_name || item.assigned_team}</td>
          <td>${item.assignee_name || '<span style="color:#38bdf8; font-weight:600;">Unassigned</span>'}</td>
          <td>${slaBadge}</td>
        `;
        tbody.appendChild(tr);
      });
    }

    // Pagination info
    const start = data.total === 0 ? 0 : currentOffset + 1;
    const end = Math.min(currentOffset + currentLimit, data.total);
    document.getElementById('paginationInfo').textContent = `Showing ${start} to ${end} of ${data.total} items`;
    document.getElementById('btnPrevPage').disabled = currentOffset === 0;
    document.getElementById('btnNextPage').disabled = !data.has_more;
  } catch (err) {
    console.error(err);
    showToast('Failed to load work items', 'error');
  }
}

// ----------------- ITEM DETAIL DRAWER & ACTIONS -----------------

async function openItemDetail(itemId) {
  try {
    const res = await apiFetch(`/api/work-items/${itemId}`);
    if (!res.ok) throw new Error('Failed to load item detail');
    const item = await res.json();
    currentItemDetail = item;

    document.getElementById('detailTitle').textContent = item.title;
    document.getElementById('detailDescription').textContent = item.description;
    document.getElementById('detailCategory').textContent = item.category.replace('_', ' ');
    document.getElementById('detailPriority').innerHTML = `<span class="badge-priority priority-${item.priority.toLowerCase()}">${item.priority}</span>`;
    document.getElementById('detailStatus').innerHTML = `<span class="badge-status status-${item.status.toLowerCase()}">${item.status.replace('_', ' ')}</span>`;
    document.getElementById('detailTeam').textContent = item.assigned_team_name || item.assigned_team;
    document.getElementById('detailAssignee').textContent = item.assignee_name || 'Unassigned';
    document.getElementById('detailVersion').textContent = `v${item.version} (OCC Key)`;
    document.getElementById('detailCreated').textContent = new Date(item.created_at).toLocaleString();
    document.getElementById('detailSla').textContent = `${item.target_sla_minutes} min (Risk: ${item.sla_risk_level})`;

    // Render Next Required Actions
    renderNextActions(item);

    // Render Audit Events
    renderAuditTimeline(item.events || []);

    document.getElementById('itemDetailModal').style.display = 'flex';
  } catch (err) {
    console.error(err);
    showToast('Failed to open item details', 'error');
  }
}

function renderNextActions(item) {
  const container = document.getElementById('nextActionsContainer');
  container.innerHTML = '';

  const actions = item.next_required_actions || [];
  if (actions.length === 0) {
    container.innerHTML = '<span style="color: var(--text-muted); font-size: 0.85rem;">No immediate actions required for this item state.</span>';
    return;
  }

  actions.forEach(action => {
    const btn = document.createElement('button');
    btn.className = 'btn';
    btn.dataset.actionType = action.action_type;

    if (!action.permitted_for_viewer) {
      btn.className += ' btn-secondary';
      btn.disabled = true;
      btn.title = `Action restricted to teams: [${action.allowed_roles_or_teams.join(', ')}]`;
      btn.innerHTML = `🔒 ${action.label} <span style="font-size:0.7rem; opacity:0.7;">(Restricted)</span>`;
    } else {
      if (action.action_type === 'APPROVE') {
        btn.className += ' btn-success';
        btn.onclick = () => promptApproval(item.id, item.version, true);
      } else if (action.action_type === 'REJECT') {
        btn.className += ' btn-danger';
        btn.onclick = () => promptApproval(item.id, item.version, false);
      } else if (action.action_type === 'CLAIM') {
        btn.className += ' btn-primary';
        btn.onclick = () => executeClaim(item.id, item.version);
      } else if (action.action_type === 'RESOLVE') {
        btn.className += ' btn-success';
        btn.onclick = () => promptResolution(item.id, item.version);
      } else if (action.action_type === 'INVESTIGATE') {
        btn.className += ' btn-secondary';
        btn.onclick = () => executeTransition(item.id, item.version, 'IN_INVESTIGATION', 'Investigating root cause');
      } else if (action.action_type === 'REQUEST_APPROVAL') {
        btn.className += ' btn-secondary';
        btn.onclick = () => executeTransition(item.id, item.version, 'PENDING_APPROVAL', 'Escalated for approval');
      } else if (action.action_type === 'BLOCK') {
        btn.className += ' btn-secondary';
        btn.onclick = () => executeTransition(item.id, item.version, 'BLOCKED', 'External blocker encountered');
      } else if (action.action_type === 'UNBLOCK') {
        btn.className += ' btn-primary';
        btn.onclick = () => executeTransition(item.id, item.version, 'IN_PROGRESS', 'External blocker cleared');
      } else {
        btn.className += ' btn-secondary';
      }
      btn.textContent = action.label;
    }
    container.appendChild(btn);
  });
}

function renderAuditTimeline(events) {
  const container = document.getElementById('auditTimelineList');
  container.innerHTML = '';

  if (events.length === 0) {
    container.innerHTML = '<span style="color: var(--text-muted); font-size: 0.8rem;">No events recorded yet.</span>';
    return;
  }

  events.forEach(ev => {
    const item = document.createElement('div');
    item.className = 'timeline-item';

    let icon = '📝';
    if (ev.event_type === 'CREATED') icon = '✨';
    if (ev.event_type === 'CLAIMED') icon = '✋';
    if (ev.event_type === 'APPROVED') icon = '✅';
    if (ev.event_type === 'REJECTED') icon = '❌';
    if (ev.event_type === 'STATUS_CHANGED') icon = '🔄';
    if (ev.event_type === 'ENRICHED') icon = '⚡';
    if (ev.event_type === 'COMMENT_ADDED') icon = '💬';

    const timeStr = new Date(ev.created_at).toLocaleString();
    let detailText = '';
    if (ev.from_state && ev.to_state) {
      detailText = `Transition: <span style="color:#38bdf8;">${ev.from_state}</span> → <span style="color:#10b981;">${ev.to_state}</span>`;
    }
    if (ev.details) {
      if (ev.details.comment) detailText = `"${escapeHtml(ev.details.comment)}"`;
      else if (ev.details.reason) detailText += ` (Reason: ${escapeHtml(ev.details.reason)})`;
      else if (ev.details.decision_notes) detailText += ` (Decision: ${escapeHtml(ev.details.decision_notes)})`;
      else if (ev.details.resolution_notes) detailText += ` (Resolution: ${escapeHtml(ev.details.resolution_notes)})`;
    }

    item.innerHTML = `
      <div class="timeline-dot">${icon}</div>
      <div class="timeline-content">
        <div class="timeline-top">
          <span class="timeline-actor">${escapeHtml(ev.actor_name)} <span style="font-size:0.7rem; color:var(--text-muted);">(${ev.event_type})</span></span>
          <span class="timeline-time">${timeStr}</span>
        </div>
        <div class="timeline-details">${detailText}</div>
      </div>
    `;
    container.appendChild(item);
  });
}

// Action Handlers
async function executeClaim(itemId, expectedVersion) {
  try {
    const res = await apiFetch(`/api/work-items/${itemId}/claim`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ expected_version: expectedVersion })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.detail?.message || err.detail || 'Claim failed');
    }
    showToast('Work item successfully claimed!', 'success');
    openItemDetail(itemId);
    if (currentTab === 'dashboard') loadDashboard();
    if (currentTab === 'items') loadWorkItems();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function executeTransition(itemId, expectedVersion, targetStatus, reason, resolutionNotes = null) {
  try {
    const res = await apiFetch(`/api/work-items/${itemId}/transition`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        expected_version: expectedVersion,
        target_status: targetStatus,
        reason: reason,
        resolution_notes: resolutionNotes
      })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.detail?.message || err.detail || 'Transition failed');
    }
    showToast(`Status updated to ${targetStatus}`, 'success');
    openItemDetail(itemId);
    if (currentTab === 'dashboard') loadDashboard();
    if (currentTab === 'items') loadWorkItems();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function promptResolution(itemId, expectedVersion) {
  const notes = prompt('Enter mandatory resolution notes explaining the fix / outcome:');
  if (notes === null) return;
  if (notes.trim().length < 5) {
    alert('Resolution notes must be at least 5 characters.');
    return;
  }
  executeTransition(itemId, expectedVersion, 'RESOLVED', 'Issue resolved and verified', notes.trim());
}

function promptApproval(itemId, expectedVersion, approved) {
  const actionName = approved ? 'approve' : 'reject';
  const notes = prompt(`Enter formal decision notes to ${actionName} this request:`);
  if (notes === null) return;
  if (notes.trim().length < 2) {
    alert('Decision notes are required.');
    return;
  }
  executeApproval(itemId, expectedVersion, approved, notes.trim());
}

async function executeApproval(itemId, expectedVersion, approved, notes) {
  try {
    const res = await apiFetch(`/api/work-items/${itemId}/approve`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        expected_version: expectedVersion,
        approved: approved,
        notes: notes
      })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.detail?.message || err.detail || 'Approval failed');
    }
    showToast(`Request ${approved ? 'approved' : 'rejected'} successfully`, 'success');
    openItemDetail(itemId);
    if (currentTab === 'dashboard') loadDashboard();
    if (currentTab === 'items') loadWorkItems();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function addCommentToCurrentItem() {
  const input = document.getElementById('newCommentInput');
  const comment = input.value.trim();
  if (!comment || !currentItemDetail) return;

  try {
    const res = await apiFetch(`/api/work-items/${currentItemDetail.id}/comments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ comment })
    });
    if (!res.ok) throw new Error('Failed to record comment');
    input.value = '';
    showToast('Comment added to audit timeline', 'success');
    openItemDetail(currentItemDetail.id);
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// ----------------- CRITICAL BEHAVIORS SIMULATOR -----------------

async function simulateRaceConditionClaim() {
  const resultBox = document.getElementById('simResultBox');
  resultBox.textContent = 'Simulating 2 concurrent claims on wi_p0_unassigned_gateway...\n';

  try {
    // Check initial state
    const initRes = await fetch('/api/work-items/wi_p0_unassigned_gateway');
    const initData = await initRes.json();
    resultBox.textContent += `Target Item: ${initData.id}\nCurrent Assignee: ${initData.assignee_id || 'None (Unassigned)'}\nCurrent Version: ${initData.version}\n\n`;

    resultBox.textContent += `[Dispatching Concurrent Requests]:\n- Worker 1: Bob Martinez (incident_response)\n- Worker 2: Eve Adams (incident_response & ops_admin)\n\n`;

    // Fire parallel claims
    const [res1, res2] = await Promise.all([
      fetch('/api/work-items/wi_p0_unassigned_gateway/claim', {
        method: 'POST',
        headers: { 'X-User-Id': 'usr_bob', 'Content-Type': 'application/json' },
        body: JSON.stringify({ expected_version: initData.version })
      }),
      fetch('/api/work-items/wi_p0_unassigned_gateway/claim', {
        method: 'POST',
        headers: { 'X-User-Id': 'usr_eve', 'Content-Type': 'application/json' },
        body: JSON.stringify({ expected_version: initData.version })
      })
    ]);

    const data1 = await res1.json();
    const data2 = await res2.json();

    resultBox.textContent += `Worker 1 Response: HTTP ${res1.status}\n${JSON.stringify(data1, null, 2)}\n\n`;
    resultBox.textContent += `Worker 2 Response: HTTP ${res2.status}\n${JSON.stringify(data2, null, 2)}\n\n`;

    const statuses = [res1.status, res2.status].sort();
    if (statuses[0] === 200 && statuses[1] === 409) {
      resultBox.textContent += `\n>> SUCCESS: Race condition prevented! Exactly 1 claim succeeded (200 OK) and 1 failed with 409 Conflict.\n`;
    } else {
      resultBox.textContent += `\n>> Result Statuses: ${statuses.join(', ')}\n`;
    }
  } catch (err) {
    resultBox.textContent += `Error in simulation: ${err.message}`;
  }
}

async function simulateStaleOCCUpdate() {
  const resultBox = document.getElementById('simResultBox');
  resultBox.textContent = 'Simulating Stale OCC (Optimistic Concurrency Control) Update...\n';

  try {
    const itemRes = await fetch('/api/work-items/wi_p2_csv_export');
    const item = await itemRes.json();
    resultBox.textContent += `Item current database version is: v${item.version}\n`;
    resultBox.textContent += `Attempting transition using intentionally STALE version: v${item.version - 1}...\n\n`;

    const res = await fetch(`/api/work-items/wi_p2_csv_export/transition`, {
      method: 'POST',
      headers: { 'X-User-Id': 'usr_alice', 'Content-Type': 'application/json' },
      body: JSON.stringify({
        expected_version: item.version - 1,
        target_status: 'IN_INVESTIGATION',
        reason: 'Simulated stale overwrite attempt'
      })
    });

    const body = await res.json();
    resultBox.textContent += `Server Response: HTTP ${res.status}\n${JSON.stringify(body, null, 2)}\n\n`;
    if (res.status === 409) {
      resultBox.textContent += `>> SUCCESS: Server rejected stale mutation with 409 Conflict. Silent overwrite prevented!`;
    }
  } catch (err) {
    resultBox.textContent += `Error: ${err.message}`;
  }
}

async function simulateIdempotencyReplay() {
  const resultBox = document.getElementById('simResultBox');
  resultBox.textContent = 'Simulating HTTP Idempotency-Key network retry & deduplication...\n';

  const testKey = 'sim_key_' + Math.random().toString(36).substring(2, 9);
  const payload = {
    title: 'Idempotency Test Item ' + Date.now(),
    description: 'Verifying idempotent execution and replay caching.',
    category: 'operational_task',
    priority: 'P2',
    assigned_team: 'tier1_support'
  };

  resultBox.textContent += `Generated Idempotency-Key: ${testKey}\n\n`;
  resultBox.textContent += `[Request 1: Initial Submission]\n`;

  const r1 = await fetch('/api/work-items', {
    method: 'POST',
    headers: {
      'X-User-Id': 'usr_alice',
      'Idempotency-Key': testKey,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });
  const b1 = await r1.json();
  resultBox.textContent += `Status: HTTP ${r1.status}, X-Idempotency-Replay Header: ${r1.headers.get('X-Idempotency-Replay') || 'None'}\nCreated Item ID: ${b1.id}\n\n`;

  resultBox.textContent += `[Request 2: Network Retry Re-sending Identical Idempotency-Key]\n`;
  const r2 = await fetch('/api/work-items', {
    method: 'POST',
    headers: {
      'X-User-Id': 'usr_alice',
      'Idempotency-Key': testKey,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });
  const b2 = await r2.json();
  resultBox.textContent += `Status: HTTP ${r2.status}, X-Idempotency-Replay Header: ${r2.headers.get('X-Idempotency-Replay')}\nReturned Item ID: ${b2.id}\n\n`;

  if (r2.headers.get('X-Idempotency-Replay') === 'true' && b1.id === b2.id) {
    resultBox.textContent += `>> SUCCESS: Server recognized repeated request key and safely replayed cached receipt without duplicate item creation!`;
  }
}

async function simulateCrossTeamUnauthorized() {
  const resultBox = document.getElementById('simResultBox');
  resultBox.textContent = 'Simulating Cross-Team Authorization Failure (Direct API Call)...\n';
  resultBox.textContent += `User: Alice Chen (teams: [tier1_support])\n`;
  resultBox.textContent += `Target: wi_p0_unassigned_gateway (assigned_team: incident_response)\n\n`;

  const res = await fetch('/api/work-items/wi_p0_unassigned_gateway/claim', {
    method: 'POST',
    headers: { 'X-User-Id': 'usr_alice', 'Content-Type': 'application/json' },
    body: JSON.stringify({ expected_version: 1 })
  });
  const body = await res.json();

  resultBox.textContent += `Server Response: HTTP ${res.status}\n${JSON.stringify(body, null, 2)}\n\n`;
  if (res.status === 403) {
    resultBox.textContent += `>> SUCCESS: Server-side RBAC enforced 403 Forbidden! Security is not reliant on frontend UI hiding.`;
  }
}

// ----------------- ASYNC JOBS INSPECTOR -----------------

async function loadAsyncJobs() {
  try {
    const res = await apiFetch('/api/async-jobs');
    const jobs = await res.json();
    const tbody = document.getElementById('asyncJobsTableBody');
    tbody.innerHTML = '';

    if (jobs.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-muted); padding: 1.5rem;">No background jobs found.</td></tr>`;
      return;
    }

    jobs.forEach(j => {
      const tr = document.createElement('tr');
      let statusColor = '#38bdf8';
      if (j.status === 'COMPLETED') statusColor = '#10b981';
      if (j.status === 'DEAD_LETTER') statusColor = '#ef4444';
      if (j.status === 'PENDING') statusColor = '#fbbf24';

      tr.innerHTML = `
        <td style="font-family:monospace; font-size:0.75rem;">${j.id}</td>
        <td><strong>${j.job_type}</strong></td>
        <td><a href="#" onclick="openItemDetail('${j.work_item_id}'); return false;" style="color:#38bdf8;">${j.work_item_id}</a></td>
        <td><span style="color:${statusColor}; font-weight:700;">${j.status}</span></td>
        <td>${j.attempts} / ${j.max_attempts}</td>
        <td style="font-size:0.75rem; color:var(--text-muted);">${new Date(j.run_at).toLocaleTimeString()}</td>
        <td style="font-size:0.75rem; color:#ef4444; max-width:200px; overflow:hidden; text-overflow:ellipsis;">${j.last_error || '-'}</td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    console.error(err);
    showToast('Failed to load async jobs', 'error');
  }
}

async function triggerDueAsyncJobs() {
  try {
    const res = await apiFetch('/api/async-jobs/run-pending', { method: 'POST' });
    const data = await res.json();
    showToast(data.message, 'success');
    loadAsyncJobs();
  } catch (err) {
    showToast('Failed to trigger background jobs', 'error');
  }
}

// ----------------- RESET DEMO STATE -----------------

async function resetDemoData() {
  if (!confirm('Reset database to clean default seed state?')) return;
  try {
    const res = await apiFetch('/api/reset-demo', { method: 'POST' });
    const data = await res.json();
    showToast(data.message, 'success');
    if (currentTab === 'dashboard') loadDashboard();
    if (currentTab === 'items') loadWorkItems();
    if (currentTab === 'async') loadAsyncJobs();
  } catch (err) {
    showToast('Failed to reset demo database', 'error');
  }
}

// ----------------- EVENT LISTENERS -----------------

function setupEventListeners() {
  // Persona switcher
  document.getElementById('personaSelect').addEventListener('change', (e) => {
    setCurrentUser(e.target.value);
  });

  // Nav tabs
  document.querySelectorAll('.nav-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => switchTab(btn.dataset.tab));
  });

  // Filter inputs
  const searchInput = document.getElementById('filterSearch');
  let searchTimeout = null;
  searchInput.addEventListener('input', (e) => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      currentFilters.search = e.target.value.trim();
      currentOffset = 0;
      loadWorkItems();
    }, 300);
  });

  document.getElementById('filterStatus').addEventListener('change', (e) => {
    currentFilters.status = e.target.value;
    currentOffset = 0;
    loadWorkItems();
  });

  document.getElementById('filterPriority').addEventListener('change', (e) => {
    currentFilters.priority = e.target.value;
    currentOffset = 0;
    loadWorkItems();
  });

  document.getElementById('filterTeam').addEventListener('change', (e) => {
    currentFilters.assigned_team = e.target.value;
    currentOffset = 0;
    loadWorkItems();
  });

  document.getElementById('filterSla').addEventListener('change', (e) => {
    currentFilters.sla_risk_level = e.target.value;
    currentOffset = 0;
    loadWorkItems();
  });

  // Pagination buttons
  document.getElementById('btnPrevPage').addEventListener('click', () => {
    if (currentOffset >= currentLimit) {
      currentOffset -= currentLimit;
      loadWorkItems();
    }
  });

  document.getElementById('btnNextPage').addEventListener('click', () => {
    currentOffset += currentLimit;
    loadWorkItems();
  });

  // Modals close
  document.getElementById('btnCloseDetailModal').addEventListener('click', () => {
    document.getElementById('itemDetailModal').style.display = 'none';
  });

  document.getElementById('itemDetailModal').addEventListener('click', (e) => {
    if (e.target.id === 'itemDetailModal') {
      document.getElementById('itemDetailModal').style.display = 'none';
    }
  });

  // Create item modal
  document.getElementById('btnOpenCreateModal').addEventListener('click', () => {
    document.getElementById('createItemModal').style.display = 'flex';
  });

  document.getElementById('btnCloseCreateModal').addEventListener('click', () => {
    document.getElementById('createItemModal').style.display = 'none';
  });

  document.getElementById('createItemForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const title = document.getElementById('createTitle').value.trim();
    const description = document.getElementById('createDescription').value.trim();
    const category = document.getElementById('createCategory').value;
    const priority = document.getElementById('createPriority').value;
    const assigned_team = document.getElementById('createTeam').value;

    try {
      const res = await apiFetch('/api/work-items', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Idempotency-Key': 'client_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7)
        },
        body: JSON.stringify({ title, description, category, priority, assigned_team })
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || 'Creation failed');
      }
      showToast('Work item created successfully!', 'success');
      document.getElementById('createItemModal').style.display = 'none';
      document.getElementById('createItemForm').reset();
      loadWorkItems();
      if (currentTab === 'dashboard') loadDashboard();
    } catch (err) {
      showToast(err.message, 'error');
    }
  });
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>'"]/g, 
    tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag)
  );
}
